//
//  CalTrackApp.swift
//  CalTrack
//
//  Created by Joshua Caiata on 2/13/24.
//

import SwiftUI

@main
struct CalTrackApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
